function start() {
    document.getElementById("startButton").disabled = true;
    document.getElementById("stopButton").disabled = false;
   document.getElementById("data").rows["round1"].innerHTML = "Start inactive...";
   document.getElementById("data").rows["round2"].innerHTML = "Stop active...";
}

function stop() {
    document.getElementById("data").rows["round1"].innerHTML = "<td>Round 2:</><td>2</td><td>4</td><td>6</td><td>8</td></td>";
  
     document.getElementById("startButton").disabled = false;
    document.getElementById("stopButton").disabled = true;
}


function playStation() {
    mySound = new sound("us-lab-background.mp3");
    mySound.play();
}

function playOddity() {
    mySound = new sound("David_Bowie_Space_Oddity.mp3");
    mySound.play();
}

function sound(src) {
    this.sound = document.createElement("audio");
    this.sound.src = src;
   
    this.play = function() {
        this.sound.play();
    }
   
}